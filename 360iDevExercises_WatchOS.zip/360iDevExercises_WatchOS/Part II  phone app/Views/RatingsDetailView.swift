//
//  RatingsDetailView.swift
//  HuliPizzaMenuWatch Extension
//
//  Created by Steven Lipton on 7/28/20.
//

import SwiftUI

struct RatingsDetailView: View {
    var myRating:Int = 0
    @Binding var isPresented:Bool
    var body: some View {
        VStack {
            Text("Rating: \(myRating)")
            RatingsView(count: .constant(myRating))
            Image("\(item.id)_100w")
        }
    }
}

struct RatingsDetailView_Previews: PreviewProvider {
    static var previews: some View {
        RatingsDetailView(item:MenuModel.menu[6].ratings,isPresented: .constant(true))
    }
}
