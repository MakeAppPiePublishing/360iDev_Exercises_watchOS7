//
//  DetailView.swift
//  HuliPizzaMenuWatch Extension
//
//  Created by Steven Lipton on 7/27/20.
//

import SwiftUI
import ClockKit

struct DetailView: View {
    var item:MenuItem
    var body: some View {
        VStack {
            HStack {
                Text(item.name)
                    .fontWeight(.heavy)
                Spacer()
            }
            Image("\(item.id)_100w")
                .cornerRadius(10)
            }
            Text(item.description)
        }
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView(item:MenuModel.menu[2])
    }
}
