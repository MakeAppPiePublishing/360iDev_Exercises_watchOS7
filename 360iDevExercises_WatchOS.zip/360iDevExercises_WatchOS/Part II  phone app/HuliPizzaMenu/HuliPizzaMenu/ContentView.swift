//
//  ContentView.swift
//  HuliPizzaMenu
//
//  Created by Steven Lipton on 8/8/20.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        PizzaOrderView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
