//
//  HuliPizzaMenuApp.swift
//  HuliPizzaMenu
//
//  Created by Steven Lipton on 7/27/20.
//

import SwiftUI

@main
struct HuliPizzaMenuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
